import re
import json

# Define log file path (change this to your actual log file)
log_file_path = "output-17thfeb2025-6.txt"

import re
import ast
import json


# List to store extracted fused answers
results_1 = []

# Regular expression to match 'fuse_generations:-' followed by a list
pattern = r"fuse_generations:- (\[.*?\])"

# Read log file and extract fuse_generations
batch = []  # Temporary storage for grouping 5 elements at a time
with open(log_file_path, "r", encoding="utf-8") as f:
    for line in f:
        match = re.search(pattern, line)
        if match:
            extracted_text = match.group(1).strip()
            try:
                # Use ast.literal_eval() to safely convert to Python list
                fused_list = ast.literal_eval(extracted_text)
                
                # Ensure it's a list
                if isinstance(fused_list, list):
                    batch.append(fused_list[0])  # Extract only the single string inside the list

                    # Once we have 5 answers, store them as a batch
                    if len(batch) == 5:
                        results_1.append(batch)
                        batch = []  # Reset batch for next set of 5 answers

            except (SyntaxError, ValueError) as e:
                print(f"Error parsing line: {line}\n{e}")

# Save recovered results to a JSON file
with open("recovered_results.json", "w", encoding="utf-8") as f:
    json.dump(results_1, f, indent=4, ensure_ascii=False)  # Ensure UTF-8 encoding

# Print the reconstructed results_1
print("Recovered results_1:", results_1)
