import time


if __name__=='__main__':
    
    print('Hi')
    time.sleep(5)
    print('bye')